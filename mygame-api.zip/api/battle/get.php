<?php
$data = array('data' => array(
	'characters' => array(
		'hero' => array(
			'type' => 'human',
			'img' => 'ahdfgswkfh',
			'dir' => 'r',
			'x' => 10,
			'y' => 9,
			'speed' => 3,
			'dmgtype' => 'blood',
			'height' => 55
		),
		'a' => array(
			'type' => 'skeleton',
			'img' => 'z35ts4dgsd',
			'dir' => 'l',
			'x' => 7,
			'y' => 1,
			'speed' => 2,
			'wr' => 'axe',
			'dmgtype' => 'ash',
			'height' => 60
		),
		'b' => array(
			'leader' => true,
			'type' => 'skeleton',
			'dir' => 'r',
			'img' => 'jlgjllejk4',
			'x' => 3,
			'y' => 2,
			'speed' => 7,
			'wr' => 'axe',
			'dmgtype' => 'ash',
			'height' => 67
		),
		'd' => array(
			'type' => 'skeleton',
			'dir' => 'r',
			'img' => 'afgesgjkr7',
			'x' => 4,
			'y' => 5,
			'speed' => 5,
			'wr' => 'axe',
			'dmgtype' => 'ash',
			'height' => 64
		)
	),
	'dictionary' => array(
		'endturn' => 'Пропустить ход'
	)
));

die(json_encode($data));

