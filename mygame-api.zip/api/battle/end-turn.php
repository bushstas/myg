<?php
$data = array('data' => array(
	array('id' => 'a', 'props' => array('x' => 7, 'y' => 2), 'duration' => 13),
	array('id' => 'b', 'props' => array('dir' => 'rh', 'sayKey' => 1, 'say' => 'Kill him!!!'), 'duration' => 20),
	array('id' => 'b', 'props' => array('dir' => 'r')),
	array('id' => 'd', 'props' => array('hitKey' => 1, 'hit' => array())),
	array('id' => 'hero', 'props' => array('dmgKey' => 1, 'dmg' => 10)),
	array('id' => 'a', 'props' => array('dmgKey' => 2, 'dmg' => 10), 'duration' => 10),
));

die(json_encode($data));

