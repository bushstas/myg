<?php

$areas = array(
	'id' => 'efdklhjufk',
	'monsters' => array(
		'skeleton' => 3,
		'zombie' => 1
	),
	'level' => 1,
	'maxGroupsCounts' => (1 => 10, 2 => 1),
	'minMonsters' => 3,
	'maxMonsters' => 5,
	'minMonsterLevel' => 1,
	'maxMonsterLevel' => 5,
	'withLeader' => array('y' => 1, 'n' => 5)
);