<?php

$monsters = array(
	'skeleton' => array(
		'hfhdyr48jd' => array(
			'level' => 1,
			'img' => '',
			'height' => 0,
			'attack' => array(
				'melee' => 5
			),
			'dmg' => array(
				'r' => array(1, 4)
			),
			'defense' => array(
				'armor' => 0,
				'parry' => 3,
				'evasion' => 1
			),
			'speed' => array(
				'a' => 16,
				'w' => 10
			),
			'resist' => array(
				'fire': -20,
				'air': 5,
				'water': 10,
				'earth': -30,
				'dark': 40,
				'lignt': -80
			)
		)
	)
);