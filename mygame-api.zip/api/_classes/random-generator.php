<?php

class RandomGenerator {
	static function generate($from, $to) {
		return rand($from, $to);
	}

	static function getByChance($chances) {
		$values = array();
		foreach ($chances as $key => $value) {
			for ($i = 0; $i < $value; $i++) {
				$values[] = $key;
			}
		}
		shuffle($values);
		$random = rand(0, count($values) - 1);
		return $values[$random];
	}

	static function getBooleanByChance($chances) {
		return self::getByChance($chances) == 'y';
	}

	static function pickRandom($items) {
		$index = rand(0, count($items) - 1);
		shuffle($items);
		return $items[$index];
	}
}
