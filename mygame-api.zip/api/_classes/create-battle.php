<?php

include '../_data/areas.php';
include './monsters.php';
include './random-generator.php';

class BattleCreator {
	static function create($options) {
		extract($options);

		$areaData = $areas[$area];
		$enemies = self::createEnemies($options);
	}

	static function createEnemies($options) {
		extract($options);
		$groups = array();
		$groupsCount = 1;
		if (!empty($maxGroupsCounts) && is_array($maxGroupsCounts)) {
			$groupsCount = RandomGenerator::getByChance($maxGroupsCounts);
		} 
		for ($i = 0; $i < $groupsCount; $i++) {
			$type = RandomGenerator::getByChance($monsters);
			$groups[] = self::createEnemyGroup($type, $options);
		}
	}

	static function createEnemyGroup($type, $options) {
		extract($options);
		$enemyCount = RandomGenerator::generate($minMonsters, $maxMonsters);
		$withLeader = RandomGenerator::getBooleanByChance($withLeader);
		$enemies = array();
		for ($i = 0; $i < $enemyCount; $i++) {
			$enemies[] = self::createEnemy($type, $options, $withLeader && $i == 0);
		}
		return $enemies;
	}

	static function createEnemy($type, $options, $isLeader) {
		extract($options);
		$level = RandomGenerator::generate($minMonsterLevel, $maxMonsterLevel);
		if ($isLeader) {
			$level += RandomGenerator::getByChance(array(1 => 4, 2 => 8, 3 => 2, 4 => 1));
		}
		$monsters = Monsters::getByTypeAndLevel($type, $level);
		$monster = RandomGenerator::pickRandom($monsters);

		return $monster;
	}
}