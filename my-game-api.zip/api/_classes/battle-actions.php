<?php

include __DIR__.'/random-generator.php';
include __DIR__.'/../_data/battle-cries.php';

class BattleActions {
	static private $actions;

	static function init() {
		self::$actions = array();
	}

	private static function add($id, $props, $duration = 0, $key = null) {
		if ($key !== null) {
			$props[$key.'Key'] = RandomGenerator::generateRandomString();
		}
		$action = array('id' => $id, 'props' => $props, 'duration' => $duration);
		array_push(self::$actions, $action);
	}

	static function command($id, $data, $leaderType) {
		global $battleCries;
		$cry = RandomGenerator::pickRandom($battleCries[$data['type']]);
		self::add($id, array('dir' => $data['dir'].'h', 'say' => $cry), 20, 'say');
		if ($leaderType === 2) {
			
		}
		self::add($id, array('dir' => $data['dir']));
	}

	static function get() {
		return self::$actions;
	}
}