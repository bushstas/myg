<?php

$battleCries = array(
	'skeleton' => array(
		'Kill him',
		'Die, mortal'
	)
);