<?php

$monsters = array(
	'skeleton' => array(
		'hfhdyr48jd' => array(
			'level' => 1,
			'img' => 'z35ts4dgsd',
			'hp' => array(6, 8),
			'rweapon' => 'axe',
			'attack' => array(
				'melee' => 5
			),
			'dmg' => array(
				'r' => array(1, 4)
			),
			'defense' => array(
				'armor' => 0,
				'parry' => 3,
				'evasion' => 1
			),
			'speed' => array(
				'a' => 16,
				'w' => 10
			),
			'resist' => array(
				'fire' => -20,
				'air' => 5,
				'water' => 10,
				'earth' => -30,
				'dark' => 40,
				'lignt' => -80
			)
		),
		'hdhdgdshs7' => array(
			'level' => 2,
			'img' => 'afgesgjkr7',
			'hp' => array(8, 10),
			'rweapon' => 'axe',
			'attack' => array(
				'melee' => 7
			),
			'dmg' => array(
				'r' => array(2, 5)
			),
			'defense' => array(
				'armor' => 0,
				'parry' => 3,
				'evasion' => 2
			),
			'speed' => array(
				'a' => 16,
				'w' => 10
			),
			'resist' => array(
				'fire' => -20,
				'air' => 5,
				'water' => 10,
				'earth' => -30,
				'dark' => 40,
				'lignt' => -80
			)
		),
		'lajj6kjdhs' => array(
			'level' => 3,
			'img' => 'jlgjllejk4',
			'hp' => array(12, 16),
			'rweapon' => 'axe',
			'attack' => array(
				'melee' => 10
			),
			'dmg' => array(
				'r' => array(4, 8)
			),
			'defense' => array(
				'armor' => 1,
				'parry' => 5,
				'evasion' => 3
			),
			'speed' => array(
				'a' => 17,
				'w' => 10
			),
			'resist' => array(
				'fire' => -18,
				'air' => 10,
				'water' => 15,
				'earth' => -30,
				'dark' => 60,
				'lignt' => -80
			)
		),
		'gheao48shj' => array(
			'level' => 4,
			'img' => 'jlgjllejk4',
			'hp' => array(14, 20),
			'rweapon' => 'axe',
			'attack' => array(
				'melee' => 10
			),
			'dmg' => array(
				'r' => array(4, 8)
			),
			'defense' => array(
				'armor' => 1,
				'parry' => 5,
				'evasion' => 3
			),
			'speed' => array(
				'a' => 17,
				'w' => 10
			),
			'resist' => array(
				'fire' => -18,
				'air' => 10,
				'water' => 15,
				'earth' => -30,
				'dark' => 60,
				'lignt' => -80
			)
		)
	)
);