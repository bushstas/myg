<?php

$dmgtypes = array(
	'skeleton' => 'ash'
);