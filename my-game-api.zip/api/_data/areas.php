<?php

$areas = array(
	'efdklhjufk' => array(
		'monsters' => array(
			'skeleton' => 1
		),
		'level' => 1,
		'maxGroupsCounts' => array(1 => 10, 2 => 1),
		'minMonsters' => 3,
		'maxMonsters' => 5,
		'minMonsterLevel' => 1,
		'maxMonsterLevel' => 1
	)
);
