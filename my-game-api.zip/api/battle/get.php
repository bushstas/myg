<?php

$userId = 'skfjrfhry3wgfdy43r7d';
$file = __DIR__.'/../_users/'.$userId.'/battle.php';

$battle = json_decode(file_get_contents($file), true);

$data = array('data' => array(
	'characters' => array_merge($battle['heroes'], $battle['enemies']),
	'dictionary' => array(
		'endturn' => 'Пропустить ход'
	)
));

die(json_encode($data));

